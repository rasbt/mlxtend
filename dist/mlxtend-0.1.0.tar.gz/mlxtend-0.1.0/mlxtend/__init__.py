# Sebastian Raschka 08/13/2014
# mlxtend Machine Learning Library Extensions

__version__ = '0.1.0'

