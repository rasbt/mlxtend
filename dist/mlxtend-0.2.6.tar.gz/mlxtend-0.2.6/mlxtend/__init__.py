# Sebastian Raschka 2014-2015
# mlxtend Machine Learning Library Extensions

__version__ = '0.2.6'

