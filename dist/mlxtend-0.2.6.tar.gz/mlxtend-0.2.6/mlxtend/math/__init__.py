# Sebastian Raschka 12/21/2014
# mlxtend Machine Learning Library Extensions
# Submodules with math and statistics utilities

from .counting import num_combinations
from .counting import num_permutations
from .counting import factorial
__all__ = ["num_combinations", "num_permutations",
        "factorial"]

