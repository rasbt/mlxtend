from .lin_regplot import lin_regplot
from .linear_regression import LinearRegression

__all__ = ["lin_regplot, LinearRegression"]